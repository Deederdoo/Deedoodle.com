
    let canvas;
    let context;

    const starCount = 100;

    var boopArray = new Array();

    window.onload = init;

function init(){

    canvas = document.getElementById('backCanvas');
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
    context = canvas.getContext('2d');

    for(var i = 0; i < starCount; i++){

        boopArray.push(new Boop(context, Math.random() * canvas.width, Math.random() * canvas.height, i));
        boopArray[i].spawnBoop();
    }

    window.requestAnimationFrame(loop);
}

function loop(timeStamp){

    draw();
    window.requestAnimationFrame(loop);
}

function draw(){

    context.clearRect(0, 0, canvas.width, canvas.height);

    for(var i = 0; i < boopArray.length; i++){

        if(boopArray[i].xPos < canvas.width){
            
            boopArray[i].updateBoop(boopArray[i].xPos += 0.5, boopArray[i].yPos -= 0.2);

        }else{

            boopArray[i].updateBoop(0, Math.random() * canvas.height);
        }

        if(boopArray[i].yPos <= 0){

            boopArray[i].updateBoop(boopArray[i].xPos, canvas.height);
        }

        context.save();
        context.beginPath();
        context.lineWidth = 1;
        context.fillStyle = "#e4cb42";
        context.arc(boopArray[i].xPos, boopArray[i].yPos, Math.random() * 3, 0, 2 * Math.PI);
        context.stroke();
        context.fill();
        context.restore();
    }
}
