
//window.onload = init;

// var maxBoxWidth = 60;
// var boxWidthGrowth = 0.001;

// var loginBool = false;

// function loginPressed(){

//     loginBool = true;
// }

//     function init(){

//         window.requestAnimationFrame(loop);
//     }

//     function loop(timeStamp){

//         while(loginBool){

//             boxWidthGrowth += 0.0001;
//             document.getElementById("mainBoxId").style.width = (boxWidthGrowth + "vw");

//             if(boxWidthGrowth >= maxBoxWidth){

//                 loginBool = false;
//             }
//         }
//     }
