
class GameLoop{

    constructor(){

        window.onload = init;
    }

    init(){

        window.requestAnimationFrame(loop);
    }

    loop(timeStamp){

        draw();
    }

    draw(){


    }
}

